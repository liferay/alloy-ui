(function(){var g=function(){var p=arguments[0]||{},o=1,n=arguments.length,q=false,r,m=Object.prototype.toString;var l=function(i){return m.call(i)==="[object Function]"};if(typeof p==="boolean"){q=p;p=arguments[1]||{};o=2}if(typeof p!=="object"&&!l(p)){p={}}if(n==o){p=this;--o}for(;o<n;o++){if((r=arguments[o])!=null){for(var k in r){var h=p[k],j=r[k];if(p===j){continue}if(q&&j&&typeof j==="object"&&!j.nodeType){p[k]=g(q,h||(j.length!=null?[]:{}),j)}else{if(j!==undefined){p[k]=j}}}}}return p};var d=function(){var h=document.getElementsByTagName("script"),k,l;for(k=0;k<h.length;k=k+1){var m=h[k].src;var j=m.match(/^(.*)yui[\.-].*js(\?.*)?$/);if(j&&(l=j[1])){l=l.substring(0,l.length-4);break}}return l};
/*
	 * Alloy JavaScript Library v0.1a
	 * http://alloyui.com/
	 *
	 * Copyright (c) 2009 Liferay Inc.
	 * Licensed under the MIT license.
	 * http://alloyui.com/License
	 *
	 * Nate Cavanaugh (nate.cavanaugh@liferay.com)
	 * Eduardo Lundgren (eduardo.lundgren@liferay.com)
	 *
	 * Date: @DATE
	 * Revision: @REVISION
	 */
window.Alloy=window.Alloy||{};var e={};var a=["event","oop","widget"];var b=function(i,h){if(!h.success){throw h.msg}};if("defaults" in Alloy){e=Alloy.defaults}if(!("base" in e)){e.base=d()}var c=YUI(g({},e));var f=c.config;a.push(b);c.use.apply(c,a);Alloy=function(i){var h=this;c.config=c.merge(f,Alloy.defaults);if(i||h instanceof Alloy){return YUI(c.merge(c.config,i))}return c};g(Alloy,YUI,{__version:"0.1a",extend:g,defaults:e});Alloy.extend(Alloy.prototype,{ready:function(){var h=this;var m=Array.prototype.slice;var k=m.call(arguments,0),j=k.length-1;var l=k[j];var i=m.call(arguments,0,j);if(!i.length){i.push("event")}i.push(function(n){var o=arguments;n.on("domready",function(){l.apply(this,o)})});h.use.apply(h,i)}})})();