#!/bin/sh
ant all
