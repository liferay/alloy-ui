/*
 * YUI stub
 * @module yui
 * @submodule yui-base
 */
