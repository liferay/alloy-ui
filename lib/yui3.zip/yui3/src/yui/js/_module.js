/**
 * The YUI module contains the components required for building the
 * YUI seed file.  This includes the script loading mechanism, a
 * simple queue, and the core utilities for the library.
 * @module yui
 * @submodule yui-base
 */
