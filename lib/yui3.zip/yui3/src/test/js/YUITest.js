/*Stub for future compatibility*/
if (typeof YUITest == "undefined" || !YUITest) {
    YUITest = {
        TestRunner: Y.Test.Runner,
        ResultsFormat: Y.Test.Format,
        CoverageFormat: Y.Coverage.Format
    };
}