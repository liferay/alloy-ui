#!/bin/bash
ant all
