var Y = YUI().use('*');
